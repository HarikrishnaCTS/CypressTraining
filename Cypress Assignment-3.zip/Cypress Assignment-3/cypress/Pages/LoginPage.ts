

export default class Loginpage {

    static login(username, password){
        cy.fixture('user').then(({username, password}) =>{
            cy.login(username,password)
        })
            
    }

}